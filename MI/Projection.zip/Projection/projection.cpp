#include <iostream>
#include <fstream>
#include <opencv4/opencv2/core.hpp>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/io/ply_io.h>
#include <ctime>

using namespace std;
using namespace cv;

//path to kitti360 dataset
string kitti360 = "/media/jialin/045E58135E57FC3C/UBUNTU/KITTI360/";

//function to read information from .txt file
Mat txtRead(const string filePath, const string keyWord){
    double d;
    Mat outputMat; //matrix to be output
    ifstream inFile; 
    string path = kitti360 + filePath;
    string::size_type idx;
    string target_string;
    int strStart;
    int shape1;
    int shape2;
    if(keyWord=="P_rect_00"){
        strStart = 11;
        shape1 = 3;
        shape2 = 4;
    }
    else if(keyWord=="image_00"){
        strStart = 10;
        shape1 = 3;
        shape2 = 4;
    }
    else if(keyWord=="R_rect_00"){
        strStart = 11;
        shape1 = 3;
        shape2 = 3;
    }
    else{
        strStart = 2;
        shape1 = 3;
        shape2 = 4;
    }
    //open txt file
    inFile.open(path);
    if(!inFile){
        cout<<"unable to open file: "<<path <<endl;
        exit(1);
    }
    //go through the txt file line by line until the keyword is found, write the line into "target_string"
    while(!inFile.eof()){
        string inLine;
        getline(inFile, inLine,'\n');
        idx=inLine.rfind(keyWord,0);
        if(idx!=string::npos){
            target_string=inLine.substr(strStart);
            // cout<<"target_string: "<<target_string<<endl;
            break;
        }
    }

    //convert "target_string" into a vector "txtVec"
    vector<double> txtVec;
    stringstream ss(target_string);
    while(ss>>d){
        txtVec.push_back(d);
    }
    if(txtVec.size()==0){
        cout<<"target line not found in "<<filePath<<endl;
        exit(1);
    }

    //convert the vector "txtVec" into a matrix "txtMat"
    //the txtMat is 1xN shape, convert it to ideal shape
    Mat txtMat(txtVec);
    txtMat = txtMat.reshape(1,(shape2, shape1));
    
    //further process the txtMat into a form that can be directly used
    if(keyWord=="P_rect_00"){
        outputMat = txtMat.colRange(0,3).rowRange(0,3);
    }
    else if(keyWord=="image_00"){
        Mat addedLine = (Mat_<double>(1,4) << 0,0,0,1);
        txtMat.push_back(addedLine);
        outputMat = txtMat;
    }
    else if(keyWord=="R_rect_00"){
        outputMat = Mat::eye(4,4,CV_64FC1);
        txtMat.convertTo(txtMat, CV_64FC1);
        if (txtMat.type()!=6){
            cout<<"line 91, txtMat'type not converted to CV_64F"<<endl;
            exit(1);
        }
        for (int i=0; i<3; i++){
            for (int j=0; j<3; j++){
                outputMat.at<double>(i,j) = txtMat.at<double>(i,j);
            }
        }
    }
    else{
        Mat addedLine = (Mat_<double>(1,4) << 0,0,0,1);
        txtMat.push_back(addedLine);
        outputMat = txtMat;
    }
    
    //print out the outputMat before return it
    cout << keyWord<<outputMat << endl;

    //close the file
    inFile.close();

    return outputMat;

}


int main(){
    //////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////I cannot believe this intrinsicMat is different from the matrix output by txtRead/////
    Mat intrinsicMat = txtRead("calibration/perspective.txt", "P_rect_00"); //intrinsic matrix
    cout<<"intrinsicMat: "<<intrinsicMat<<endl;
    //////////////////////////////////////////////////////////////////////////////////////////////////
    Mat cam2poseMat = txtRead("calibration/calib_cam_to_pose.txt", "image_00"); //camera frame to GPS frame
    cout<<"cam2poseMat: "<<cam2poseMat<<endl;
    Mat rectMat = txtRead("calibration/perspective.txt", "R_rect_00"); //rectification matrix
    cout<<"rectMat: "<<rectMat<<endl;

    return 0;
}